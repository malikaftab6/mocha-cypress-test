
let Task_within_time = 15;
let Task_out_of_time = 150;

/**
 * Returns new promise to n-th tasks.
 *
 * @param value  The value return on promise resolve..
 */
const createTask = value => () => {
  return new Promise(resolve => setTimeout(() => resolve(value), value));
}

/**
 * Returns N=15 if current time is between 9am-5pm else N=150.
 * 
 * @param {string} startTime  get the availability start time
 * @param {string} endTime  get the availability end time
 */
const getLimit = (startTime = '09:00:00', endTime = '17:00:00') => {

	let currentDate = new Date();   

	startDate = new Date(currentDate.getTime());
	startDate.setHours(startTime.split(":")[0]);
	startDate.setMinutes(startTime.split(":")[1]);
	startDate.setSeconds(startTime.split(":")[2]);

	endDate = new Date(currentDate.getTime());
	endDate.setHours(endTime.split(":")[0]);
	endDate.setMinutes(endTime.split(":")[1]);
	endDate.setSeconds(endTime.split(":")[2]);

	return (startDate < currentDate && endDate > currentDate) ? Task_within_time : Task_out_of_time;
}

/**
 * This init function make a random taskslist on the base of numberOfTasks.
 * Make a promise array against all the task.
 * call manageConcurrency method.
 */
const init = async () => {  // TODO convert it in async await and handle error
	numberOfTasks = 20; 
	const taskList = [...Array(numberOfTasks)].map(() => 
	[...Array(~~(Math.random() * 10 + 3))].map(() => 
	String.fromCharCode(Math.random() * (123 - 97) + 97) 
	).join('') ) 
	console.log("[init] Concurrency Algo Testing...") 
	console.log("[init] Tasks to process: ", taskList.length) 
	console.log("[init] Task list: " + taskList) 
	console.log("[init] Maximum Concurrency: ", getLimit(),"\n");

	const tasksPromises = [];
	taskList.forEach(element => {
		tasksPromises.push(createTask(element));
	});

  try {
    let result = await manageConcurrency(tasksPromises);
    console.log('All Tasks Done.');
  } catch (error) {
    console.error(error);
  }
	 
} 
 
/**
 * Returns a promise.
 * 
 * @param {array} tasks  get the task array basically its a promises array for every task
 * @param {number} concurrencyMax  how much max task work at a time
 */
const manageConcurrency = (tasks,concurrencyMax) => {

	let taskIndex = 0; //To implement the recursion we need also a helper variable taskIndex which is keeping track of the currently running task.
	let numOfWorkers = 0; // which will go up once we run a task and then goes down when the task is finished.

  return new Promise(done => {

		// helper function called when promise is resolved
    const handleResult = index => result => {
      tasks[index] = result;
      numOfWorkers--;
			console.log('\x1b[36m', "[TASK] FINISHED: " + result ,'\x1b[0m');
      getNextTask();
    };

		// we call getNextTask just after we run the task with tasks[taskIndex](). 
		// This means that we are not waiting to see the promise resolved or rejected. 
 		// We just process the next one. What limits the workers is the first if statement. 
 		// The whole exercise ends when there are no running workers and there are no more tasks to process.
    const getNextTask = () => {
		  concurrencyMax = getLimit();// get the N limit on the base of current time 
      console.log('getNextTask numOfWorkers=' + numOfWorkers);

      if (numOfWorkers < concurrencyMax && taskIndex < tasks.length) {
        tasks[taskIndex]().then(handleResult(taskIndex)).catch(handleResult(taskIndex));
        taskIndex++;
        numOfWorkers++;
        getNextTask();
      } else if (numOfWorkers === 0 && taskIndex === tasks.length) {
        done(tasks);
      }
    };
    getNextTask();
  });
}

//call the init function 
init();