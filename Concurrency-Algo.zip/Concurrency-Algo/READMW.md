# Open folder in VScode or any complier

Commands to run:

* node index.js